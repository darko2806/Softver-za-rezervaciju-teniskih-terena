/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package kontroleri;

import forme.LoginForma;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import model.Recepcionar;

/**
 *
 * @author dare2
 */
public class LoginFormaController {
    private final LoginForma lf;
    int prviPut = 0;

    public LoginFormaController(LoginForma lf) {
        this.lf = lf;
        this.lf.setLocationRelativeTo(null);
        lf.setTitle("Prijava");
        addActionListeners();
    }

    private void addActionListeners() {
        lf.prijaviSe(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (prviPut == 0 && cordinator.Cordinator.getInstance().isKonekcija() == false) {
                    try {
                        komunikacija.Komunikacija.getInstance().konekcija();
                        prviPut++;
                        komunikacija.Komunikacija.getInstance().vratiKategorijeIgraca();
                        komunikacija.Komunikacija.getInstance().vratiIgrace();
                        komunikacija.Komunikacija.getInstance().vratiRecepcionare();
                        komunikacija.Komunikacija.getInstance().vratiTipoveTerena();
                        komunikacija.Komunikacija.getInstance().vratiRecepcionarSmena();
                        komunikacija.Komunikacija.getInstance().vratiRadnaSmena();
                        komunikacija.Komunikacija.getInstance().vratiPotvrdeRezervaciije();
                        cordinator.Cordinator.getInstance().setKonekcija(true);
                    } catch (Exception ee) {
                        JOptionPane.showMessageDialog(lf, "Ne moze da se otvori glavna forma i meni!", "Greska", JOptionPane.ERROR_MESSAGE);

                        return;
                    }
                }
                String korisnickoIme = lf.getjTextFieldKorisnickoIme().getText().trim();
                String lozinka = String.valueOf(lf.getjPasswordField().getPassword());
                Recepcionar recepcionar = new Recepcionar();
                recepcionar.setKorisnickoIme(korisnickoIme);
                recepcionar.setSifra(lozinka);

                komunikacija.Komunikacija.getInstance().login(recepcionar);
            }
        });
    }
    public void otvoriFormu() {
        lf.setVisible(true);
    }

    public void login(Recepcionar recepcionar) {
        if (recepcionar != null && recepcionar.getIdRecepcionar()== 0) {
            JOptionPane.showMessageDialog(lf, "Vec ste prijavljeni na sistem!", "Greska", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (recepcionar == null) {
            JOptionPane.showMessageDialog(lf, "Korisnicko ime i sifra nisu ispravni!", "Greska", JOptionPane.ERROR_MESSAGE);
            return;
        } else {
            JOptionPane.showMessageDialog(lf, "Korisnicko ime i sifra su ispravni.", "Uspeh", JOptionPane.INFORMATION_MESSAGE);
            cordinator.Cordinator.getInstance().setUlogovani(recepcionar);
            cordinator.Cordinator.getInstance().otvoriGlavnuFormu();
            lf.dispose();
        }
    }

    public void ugasiFormu() {
        JOptionPane.showMessageDialog(lf, "Server vas je iskljucio.", "Informacija", JOptionPane.INFORMATION_MESSAGE);
        System.exit(0);
    }
}
