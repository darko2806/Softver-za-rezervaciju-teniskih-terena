/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package kontroleri;

import forme.GlavnaForma;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import model.Recepcionar;

/**
 *
 * @author dare2
 */
public class GlavnaFormaController {
    private final GlavnaForma gf;
    private Recepcionar ulogovani = cordinator.Cordinator.getInstance().getUlogovani();
    
    public GlavnaFormaController(GlavnaForma gf) {
        this.gf = gf;
        this.gf.setLocationRelativeTo(null);
        gf.setTitle("Dobrodosli, " + ulogovani);
        addActionListeners();
    }
    
    private void addActionListeners() {
        gf.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                komunikacija.Komunikacija.getInstance().logout(ulogovani);
                System.exit(0);
            }

        });
        gf.otvoriPrikazIgraca(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cordinator.Cordinator.getInstance().otvoriPrikazIgracaFormu();
            }
        });
        gf.otvoriKreirajIgraca(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cordinator.Cordinator.getInstance().otvoriKreirajIgracaFormu();
            }
        });
        gf.odjava(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                komunikacija.Komunikacija.getInstance().logout(ulogovani);
                cordinator.Cordinator.getInstance().otvoriLoginFormu();
                gf.dispose();
            }

        });
        gf.otvoriPrikazRecepcionara(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cordinator.Cordinator.getInstance().otvoriPrikazRecepcionari();
            }
        });
        gf.otvoriUbaciRecepcionarSmenaFormu(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cordinator.Cordinator.getInstance().otvoriUbaciFormu();
            }
        });
        gf.otvoriPrikazPotvrdaRezervacije(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cordinator.Cordinator.getInstance().otvoriPrikazPotvrdaRezervacijeFormu();
            }
        });
        gf.otvoriKreirajPotvrduRezervacije(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cordinator.Cordinator.getInstance().otvoriKreirajPotvrduRezervacijeFormu();
            }
        });
    }
    public void otvoriFormu() {
        gf.setVisible(true);
    }
}
