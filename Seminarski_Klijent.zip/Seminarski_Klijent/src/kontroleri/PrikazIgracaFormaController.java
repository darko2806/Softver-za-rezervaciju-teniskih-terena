/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package kontroleri;

import forme.PrikazIgracaForma;
import forme.model.ModelIgrac;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.swing.JOptionPane;
import model.Igrac;
import model.KategorijaIgraca;

/**
 *
 * @author dare2
 */
public class PrikazIgracaFormaController {

    private final PrikazIgracaForma pif;
    private ModelIgrac model;
    private List<Igrac> lista = new ArrayList<>();
    private List<KategorijaIgraca> kategorije;
    private Igrac i;
    private List<Igrac> trenutnaLista;
    int red = -1;

    public PrikazIgracaFormaController(PrikazIgracaForma pif) {
        this.pif = pif;
        pif.setLocationRelativeTo(null);
        pif.setTitle("Prikaz igraca");
        kategorije = cordinator.Cordinator.getInstance().getKategorijeIgraca();
        pif.getjComboBoxKategorija().addItem(null);
        for (KategorijaIgraca kategorija : kategorije) {
            pif.getjComboBoxKategorija().addItem(kategorija);
        }
        lista = cordinator.Cordinator.getInstance().getIgraci();
        trenutnaLista = lista;
        popuniTabelu(lista);
        addActionListeners();
    }

    private void addActionListeners() {
        pif.ponisti(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ponisti();
            }

        });
        pif.pretrazi(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String imePrezime = pif.getjTextFieldImePrezime().getText();
                KategorijaIgraca kategorija = (KategorijaIgraca) pif.getjComboBoxKategorija().getSelectedItem();
                String kt = "";
                if (kategorija != null) {
                    kt = kategorija.toString();
                }
                Map<String, Object> mapa = new HashMap<>();
                mapa.put("ime prezime", imePrezime);
                mapa.put("kategorija", kt);
                if (imePrezime.isEmpty() && kategorija == null) {
                    JOptionPane.showMessageDialog(pif, "Niste uneli kriterijum pretrage!", "Greska", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                komunikacija.Komunikacija.getInstance().pretraziIgrace(mapa);

            }
        });
        pif.klikTabela(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                trenutnaLista = model.getLista();
                red = pif.getjTableIgraci().getSelectedRow();
                if (red != -1) {
                    i = trenutnaLista.get(red);
                    JOptionPane.showMessageDialog(pif, "Sistem je nasao igraca.", "Uspeh", JOptionPane.INFORMATION_MESSAGE);
                    cordinator.Cordinator.getInstance().otvoriPregledIgraca(i);
                }
            }

        });
    }

    public void otvoriFormu() {
        pif.setVisible(true);
    }

    public void popuniTabelu(List<Igrac> lista) {
        model = new ModelIgrac(lista);
        pif.getjTableIgraci().setModel(model);
    }

    public void sviIgraci(List<Igrac> sviIgraci) {
        lista = sviIgraci;
    }

    public void ponisti() {
        pif.getjTextFieldImePrezime().setText("");
        pif.getjComboBoxKategorija().setSelectedItem(null);
        popuniTabelu(lista);
    }

    public void osveziTabeluPrikazIgracaZbogBrisanja() {
        Igrac brisanje = trenutnaLista.get(red);
        lista.remove(brisanje);
        trenutnaLista.remove(i);
        popuniTabelu(trenutnaLista);
    }

    public void osveziTabeluPrikazIgracaZbogIzmene(Igrac ig) {
        if (red < 0 || red >= trenutnaLista.size()) {
            return;
        }
        Igrac old = trenutnaLista.get(red);
        trenutnaLista.set(red, ig);

        int id = lista.indexOf(old);
        if (id != -1) {
            lista.set(id, ig);
        }
        popuniTabelu(trenutnaLista);
    }

    public void pretrazeniIgraci(List<Igrac> pretrazeniIgraci) {
        if (pretrazeniIgraci == null || pretrazeniIgraci.isEmpty()) {
            JOptionPane.showMessageDialog(pif, "Sistem ne moze da nadje igrace po zadatim kriterijumima.", "Greska", JOptionPane.ERROR_MESSAGE);
            JOptionPane.showMessageDialog(pif, "Sistem ne moze da nadje igracа", "Greska", JOptionPane.ERROR_MESSAGE);
            return;
        }

        trenutnaLista = pretrazeniIgraci;
        popuniTabelu(trenutnaLista);
        red = -1;
        JOptionPane.showMessageDialog(pif, "Sistem je nasao igrace po zadatim kriterijumima.", "Uspeh", JOptionPane.INFORMATION_MESSAGE);
    }
}
