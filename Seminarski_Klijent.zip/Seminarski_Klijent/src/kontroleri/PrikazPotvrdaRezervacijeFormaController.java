/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package kontroleri;

import forme.PrikazPotvrdaRezervacijeForma;
import forme.model.ModelPotvrdaRezervacije;
import forme.model.ModelStavkaRezervacije;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.swing.JOptionPane;
import model.Igrac;
import model.PotvrdaRezervacije;
import model.Recepcionar;
import model.StavkaRezervacije;
import model.TipTerena;

/**
 *
 * @author dare2
 */
public class PrikazPotvrdaRezervacijeFormaController {

    private final PrikazPotvrdaRezervacijeForma pprf;
    private List<PotvrdaRezervacije> lista = new ArrayList<>();
    private List<PotvrdaRezervacije> trenutna = new ArrayList<>();
    private List<StavkaRezervacije> stavke = new ArrayList<>();
    private int red = -1;

    private ModelPotvrdaRezervacije modelPotvrdaRez;
    private ModelStavkaRezervacije modelStavke;

    public PrikazPotvrdaRezervacijeFormaController(PrikazPotvrdaRezervacijeForma pprf) {
        this.pprf = pprf;
        pprf.setTitle("Prikaz potvrde rezervacije");
        ucitajCombo();
        pprf.setLocationRelativeTo(null);
        lista = cordinator.Cordinator.getInstance().getPotvrde();
        trenutna = lista;
        popuniTabelu(lista, stavke);
        addActionListeners();
    }

    private void addActionListeners() {
        pprf.ponisti(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                pprf.getjComboBoxIgrac().setSelectedItem(null);
                pprf.getjComboBoxTipTerena().setSelectedItem(null);
                pprf.getjComboBoxRecepcionar().setSelectedItem(null);
                popuniTabelu(lista, new ArrayList<>());
            }
        });
        pprf.klikNaTabelu(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                red = pprf.getjTablePotvrdaRezervacije().getSelectedRow();
                if (red == -1) {
                    return;
                }
                PotvrdaRezervacije pr = modelPotvrdaRez.getLista().get(red);
                if (e.getClickCount() == 2 && pprf.getjTablePotvrdaRezervacije().getSelectedRow() != -1) {

                    JOptionPane.showMessageDialog(pprf, "Sistem je nasao potvrdu rezervacije.", "Uspeh", JOptionPane.INFORMATION_MESSAGE);
                    cordinator.Cordinator.getInstance().otvoriPromeniPotvrduRezervacije(pr);
                }
                stavke = pr.getStavke();
                modelStavke = new ModelStavkaRezervacije(stavke);
                pprf.getjTableStavkeRezervacije().setModel(modelStavke);
            }

        });
        pprf.pretrazi(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Recepcionar recepcionar = (Recepcionar) pprf.getjComboBoxRecepcionar().getSelectedItem();
                Igrac igrac = (Igrac) pprf.getjComboBoxIgrac().getSelectedItem();
                TipTerena tipTerena = (TipTerena) pprf.getjComboBoxTipTerena().getSelectedItem();
                String izborStatusa = pprf.getjComboBoxStatus().getSelectedItem().toString();
                boolean obradjen = izborStatusa.equalsIgnoreCase("Da");
                Map<String, Object> mapa = new HashMap<>();
                mapa.put("recepcionar", recepcionar);
                mapa.put("igrac", igrac);
                mapa.put("TipTerena", tipTerena);
                mapa.put("Obradjen", obradjen);
                komunikacija.Komunikacija.getInstance().pretraziPotvrde(mapa);

            }
        });
    }

    public void otvoriFormu() {
        pprf.setVisible(true);
    }

    private void popuniTabelu(List<PotvrdaRezervacije> lista, List<StavkaRezervacije> stavke) {
        modelPotvrdaRez = new ModelPotvrdaRezervacije(lista);
        pprf.getjTablePotvrdaRezervacije().setModel(modelPotvrdaRez);

        modelStavke = new ModelStavkaRezervacije(stavke);
        pprf.getjTableStavkeRezervacije().setModel(modelStavke);
    }

    public void pretragaPotvrdaRez(List<PotvrdaRezervacije> pretragaPotvrda) {
        if (pretragaPotvrda.size() == 0) {
            JOptionPane.showMessageDialog(pprf, "Sistem ne moze da nadje potvrde rezervacije po zadatim kriterijumima!", "Greska", JOptionPane.ERROR_MESSAGE);
            JOptionPane.showMessageDialog(pprf, "Sistem ne moze da nadje potvrde rezervacije!", "Greska", JOptionPane.ERROR_MESSAGE);
            return;
        }
        JOptionPane.showMessageDialog(pprf, "Sistem je nasao potvrde rezervacije po zadatim kriterijumima.", "Uspeh", JOptionPane.INFORMATION_MESSAGE);

        popuniTabelu(pretragaPotvrda, new ArrayList<>());
    }

    private void ucitajCombo() {
        List<Recepcionar> recepcionari = cordinator.Cordinator.getInstance().getRecepcionari();
        List<Igrac> igraci = cordinator.Cordinator.getInstance().getIgraci();
        List<TipTerena> tipoviTerena = cordinator.Cordinator.getInstance().getTipoviTerena();
        pprf.getjComboBoxIgrac().addItem(null);
        pprf.getjComboBoxTipTerena().addItem(null);
        pprf.getjComboBoxRecepcionar().addItem(null);
        for (Recepcionar recepcionar : recepcionari) {
            pprf.getjComboBoxRecepcionar().addItem(recepcionar);
        }
        for (TipTerena tt : tipoviTerena) {
            pprf.getjComboBoxTipTerena().addItem(tt);
        }
        for (Igrac i : igraci) {
            pprf.getjComboBoxIgrac().addItem(i);
        }
    }

    public void osveziTabelu(PotvrdaRezervacije pr) {
        popuniTabelu(trenutna, new ArrayList<>());
    }
}
