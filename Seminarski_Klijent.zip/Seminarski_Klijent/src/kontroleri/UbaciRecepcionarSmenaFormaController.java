/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package kontroleri;

import forme.UbaciRecepcionarSmenaForma;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Date;
import java.util.List;
import javax.swing.JOptionPane;
import model.RadnaSmena;
import model.Recepcionar;
import model.RecepcionarSmena;

/**
 *
 * @author dare2
 */
public class UbaciRecepcionarSmenaFormaController {

    private final UbaciRecepcionarSmenaForma ursf;
    private List<Recepcionar> recepcionari = cordinator.Cordinator.getInstance().getRecepcionari();
    private List<RadnaSmena> radneSmene = cordinator.Cordinator.getInstance().getRadneSmene();

    public UbaciRecepcionarSmenaFormaController(UbaciRecepcionarSmenaForma ursf) {
        this.ursf = ursf;
        ursf.setLocationRelativeTo(null);
        ursf.setTitle("Ubaci radnu smenu");
        popuniCombo();
        addActionListeners();
    }

    private void addActionListeners() {
        ursf.ubaci(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Recepcionar r = (Recepcionar) ursf.getjComboBoxRecepcionari().getSelectedItem();
                RadnaSmena rs = (RadnaSmena) ursf.getjComboBoxRadneSmene().getSelectedItem();
                String datumS = ursf.getjTextFieldDatumRada().getText().trim();
                DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd.MM.yyyy");
                LocalDateTime datum = null;
                try {
                    datum = LocalDate.parse(datumS.trim(), dtf).atStartOfDay();
                } catch (DateTimeParseException ex) {
                    JOptionPane.showMessageDialog(ursf,
                            "Datum mora biti u formatu dd.MM.yyyy (npr. 25.12.2025)",
                            "Greška", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                if (datum == null || r == null || rs == null) {
                    JOptionPane.showMessageDialog(ursf, "Sistem ne moze da zapamti termin dezurstva!", "Greska", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                RecepcionarSmena recSme = new RecepcionarSmena(datum, r, rs);
                komunikacija.Komunikacija.getInstance().ubaciRecepcionarSmenu(recSme);
                cordinator.Cordinator.getInstance().getRecepcionarSmene().add(recSme);
                JOptionPane.showMessageDialog(ursf, "Sistem je zapamtio radnu smenu!", "Uspeh", JOptionPane.INFORMATION_MESSAGE);
                ursf.dispose();
            }
        });
    }

    public void otvoriFormu() {
        ursf.setVisible(true);
    }

    private void popuniCombo() {
        ursf.getjComboBoxRadneSmene().addItem(null);
        ursf.getjComboBoxRecepcionari().addItem(null);
        for (Recepcionar r : recepcionari) {
            ursf.getjComboBoxRecepcionari().addItem(r);
        }
        for (RadnaSmena radsme : radneSmene) {
            ursf.getjComboBoxRadneSmene().addItem(radsme);
        }
    }

}
