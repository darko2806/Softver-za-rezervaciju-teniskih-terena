/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package kontroleri;

import forme.KreirajPotvrduRezervacijeForma;
import forme.model.ModelStavkaRezervacije;
import forme.model.ModelTipTerena;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.swing.JOptionPane;
import model.Igrac;
import model.PotvrdaRezervacije;
import model.Recepcionar;
import model.StavkaRezervacije;
import model.TipTerena;

/**
 *
 * @author dare2
 */
public class KreirajPotvrduRezervacijeFormaController {

    private final KreirajPotvrduRezervacijeForma kprf;
    private PotvrdaRezervacije pr = null;
    private List<Recepcionar> recepcionari = cordinator.Cordinator.getInstance().getRecepcionari();
    private List<Igrac> igraci = cordinator.Cordinator.getInstance().getIgraci();
    private PotvrdaRezervacije kreiranaPotvrda;
    private List<TipTerena> tipoviTerena = cordinator.Cordinator.getInstance().getTipoviTerena();
    private ModelTipTerena modelTipTerena;
    private ModelStavkaRezervacije modelStavke;
    private List<StavkaRezervacije> stavke = new ArrayList<>();
    private List<StavkaRezervacije> stavkeZaUklanjanje = new ArrayList<>();

    private int redTipovaTerena = -1;
    private int redStavka = -1;
    private double ukupanIznos = 0;

    public KreirajPotvrduRezervacijeFormaController(KreirajPotvrduRezervacijeForma kprf, PotvrdaRezervacije pr) {
        this.kprf = kprf;
        kprf.setTitle("Kreiraj potvrdu rezervacije");
        kprf.setLocationRelativeTo(null);
        this.pr = pr;
        popuniCombo();
        iskljuciSve();
        if (pr != null) {
            kprf.getjButtonKreiraj().setVisible(false);
            kprf.getjButtonOmoguciIzmenu().setVisible(true);
            kprf.setTitle("Pregled potvrde rezervacije");
            kprf.getjLabelNaslov().setText("Pregled potvrde rezervacije");

            popuniPregledPotvrde();
            stavke = pr.getStavke();
            ukupanIznos = pr.getCenaUkupno();
        }

        addActionListeners();
    }

    private void addActionListeners() {
        kprf.kreirajPotvrduRez(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                kreiranaPotvrda = new PotvrdaRezervacije(-1, 0, false, cordinator.Cordinator.getInstance().getNepoznatiRecepcionar(), cordinator.Cordinator.getInstance().getNepoznatiIgrac());
                komunikacija.Komunikacija.getInstance().kreirajPotvrduRezervacije(kreiranaPotvrda);
            }
        });
        kprf.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                if (kreiranaPotvrda != null && kreiranaPotvrda.getCenaUkupno() <= 0 && pr == null) {
                    komunikacija.Komunikacija.getInstance().izbrisiPotvrdu(kreiranaPotvrda);

                }

            }

        });
        kprf.omoguciIzmenu(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                kprf.getjLabelNaslov().setText("Promeni potvrdu rezervacije");
                kprf.getjButtonOmoguciIzmenu().setVisible(false);
                kprf.setTitle("Promeni potvrdu rezervacije");

                kprf.getjComboBoxIgrac().setEnabled(true);
                kprf.getjButtonDodajTipTerena().setEnabled(true);
                kprf.getjButtonIzbaciStavku().setEnabled(true);
                kprf.getjButtonZapamti().setVisible(true);
                kprf.getjTableTipoviTerena().setEnabled(true);
                kprf.getjTableStavke().setEnabled(true);
                kprf.getjButtonKreiraj().setVisible(false);
                kprf.getjComboBoxStatus().setEnabled(true);
                kprf.getjTextFieldBrojSati().setEnabled(true);
            }
        });
        kprf.zapamtiPotvrduRez(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                Recepcionar recepcionar = (Recepcionar) kprf.getjComboBoxRecepcionar().getSelectedItem();
                Igrac igrac = (Igrac) kprf.getjComboBoxIgrac().getSelectedItem();
                String obradjenVr = (String)kprf.getjComboBoxStatus().getSelectedItem();
                boolean obradjen = obradjenVr.equals("Da");
                if (stavke.size() == 0 || recepcionar == null || igrac == null) {
                    JOptionPane.showMessageDialog(kprf, "Sistem ne moze da zapamti potvrdu rezervacije!", "Greska", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                Map<String, Object> mapa = new HashMap<>();
                if (pr == null) {
                    kreiranaPotvrda.setRecepcionar(recepcionar);
                    kreiranaPotvrda.setIgrac(igrac);
                    kreiranaPotvrda.setCenaUkupno(ukupanIznos);
                    kreiranaPotvrda.setStavke(stavke);
                    kreiranaPotvrda.setObradjen(obradjen);
                    mapa.put("potvrdarezervacije", kreiranaPotvrda);
                    mapa.put("stavke", stavke);
                    mapa.put("zaBrisanje", stavkeZaUklanjanje);
                   
                } else {
                    pr.setIgrac(igrac);
                    pr.setCenaUkupno(ukupanIznos);
                    pr.setStavke(stavke);
                    pr.setObradjen(obradjen);
                    

                    mapa.put("potvrdarezervacije", pr);
                    mapa.put("stavke", stavke);
                    mapa.put("zaBrisanje", stavkeZaUklanjanje);
                    cordinator.Cordinator.getInstance().osveziPrikazPotvrdi(pr);
                }
                komunikacija.Komunikacija.getInstance().zapamtiPotvrdu(mapa);
                JOptionPane.showMessageDialog(kprf, "Sistem je zapamtio potvrdu rezervacije.", "Uspeh", JOptionPane.INFORMATION_MESSAGE);
                kprf.dispose();
            }
        });
        kprf.dodajStavku(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int red = kprf.getjTableTipoviTerena().getSelectedRow();
                if (red == -1) {
                    JOptionPane.showMessageDialog(kprf, "Morate selektovati tip terena!", "Greška", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                String brojSatiText = kprf.getjTextFieldBrojSati().getText().trim();
                if (brojSatiText.isEmpty()) {
                    JOptionPane.showMessageDialog(kprf, "Unesite broj sati!", "Greška", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                double brojSati;
                try {
                    brojSati = Double.parseDouble(brojSatiText);
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(kprf, "Broj sati mora biti numerička vrednost!", "Greška", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                if (brojSati <= 0) {
                    JOptionPane.showMessageDialog(kprf, "Broj sati mora biti veći od 0!", "Greška", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                TipTerena selektovanTip = tipoviTerena.get(red);
                double cenaPoSatu = selektovanTip.getCenaPoSatu();
                double cenaRez = cenaPoSatu * brojSati;

                StavkaRezervacije sr;
                if (pr == null) {
                    sr = new StavkaRezervacije(-1, (int) brojSati, cenaPoSatu, cenaRez, selektovanTip, kreiranaPotvrda);
                } else {
                    sr = new StavkaRezervacije(-1, (int) brojSati, cenaPoSatu, cenaRez, selektovanTip, pr);
                }

                stavke.add(sr);
                ukupanIznos += cenaRez;
                kprf.getjLabelUkupanIznos().setText(ukupanIznos + "");
                osveziTabelu(stavke);
            }
        });

        kprf.izbaciStavku(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int red = kprf.getjTableStavke().getSelectedRow();
                if (red == -1) {
                    JOptionPane.showMessageDialog(kprf, "Morate selektovati stavku!", "Greska", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                StavkaRezervacije selektovana = stavke.get(red);
                double umanjena = selektovana.getCenaRez();
                ukupanIznos -= umanjena;

                stavke.remove(red);
                stavkeZaUklanjanje.add(selektovana);

                kprf.getjLabelUkupanIznos().setText(ukupanIznos + "");

                osveziTabelu(stavke);
            }
        });
    }

    public void otvoriFormu() {
        kprf.setVisible(true);
    }

    private void popuniCombo() {
        kprf.getjComboBoxRecepcionar().addItem(null);
        for (Recepcionar recepcionar : recepcionari) {
            kprf.getjComboBoxRecepcionar().addItem(recepcionar);
        }
        kprf.getjComboBoxIgrac().addItem(null);

        for (Igrac igrac : igraci) {
            kprf.getjComboBoxIgrac().addItem(igrac);
        }
        modelTipTerena = new ModelTipTerena(tipoviTerena);
        kprf.getjTableTipoviTerena().setModel(modelTipTerena);
        modelStavke = new ModelStavkaRezervacije(stavke);
        kprf.getjTableStavke().setModel(modelStavke);

    }

    private void iskljuciSve() {
        kprf.getjButtonOmoguciIzmenu().setVisible(false);
        kprf.getjComboBoxIgrac().setEnabled(false);
        kprf.getjComboBoxRecepcionar().setEnabled(false);
        kprf.getjButtonDodajTipTerena().setEnabled(false);
        kprf.getjButtonIzbaciStavku().setEnabled(false);
        kprf.getjButtonZapamti().setVisible(false);
        kprf.getjTableTipoviTerena().setEnabled(false);
        kprf.getjTableStavke().setEnabled(false);
        kprf.getjTextFieldBrojSati().setEnabled(false);
        kprf.getjComboBoxStatus().setEnabled(false);
    }

    public void kreiranaPotvrda(int idRez) {
        if (idRez == -1) {
            JOptionPane.showMessageDialog(kprf, "Sistem ne moze da kreira potvrdu rezervacije.", "Greska", JOptionPane.ERROR_MESSAGE);
            return;
        }
        JOptionPane.showMessageDialog(kprf, "Sistem je kreirao potvrdu rezervacije.", "Uspeh", JOptionPane.INFORMATION_MESSAGE);
        kreiranaPotvrda.setIdRezervacije(idRez);
        ukljuciSve();
    }

    private void ukljuciSve() {
        kprf.getjButtonOmoguciIzmenu().setVisible(true);
        kprf.getjComboBoxIgrac().setEnabled(true);
        kprf.getjComboBoxRecepcionar().setEnabled(true);
        kprf.getjButtonDodajTipTerena().setEnabled(true);
        kprf.getjButtonIzbaciStavku().setEnabled(true);
        kprf.getjButtonZapamti().setVisible(true);
        kprf.getjTableTipoviTerena().setEnabled(true);
        kprf.getjTableStavke().setEnabled(true);
        kprf.getjTextFieldBrojSati().setEnabled(true);
        kprf.getjComboBoxStatus().setEnabled(true);
        kprf.getjButtonKreiraj().setVisible(false);
    }

    private void popuniPregledPotvrde() {
        kprf.getjComboBoxIgrac().setSelectedItem(pr.getIgrac());
        kprf.getjComboBoxRecepcionar().setSelectedItem(pr.getRecepcionar());
        kprf.getjLabelUkupanIznos().setText(pr.getCenaUkupno() + "");
        modelStavke = new ModelStavkaRezervacije(pr.getStavke());
        kprf.getjTableStavke().setModel(modelStavke);
    }

    public void osveziTabelu(List<StavkaRezervacije> stavke) {
        modelStavke = new ModelStavkaRezervacije(stavke);
        kprf.getjTableStavke().setModel(modelStavke);
    }
}
