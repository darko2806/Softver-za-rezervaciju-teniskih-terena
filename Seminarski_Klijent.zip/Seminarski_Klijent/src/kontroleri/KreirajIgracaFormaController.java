/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package kontroleri;

import forme.KreirajIgracaForma;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.List;
import javax.swing.JOptionPane;
import model.Igrac;
import model.KategorijaIgraca;

/**
 *
 * @author dare2
 */
public class KreirajIgracaFormaController {

    private final KreirajIgracaForma kif;
    private Igrac i;
    private List<KategorijaIgraca> sveKategorije;
    private boolean pregled = false;

    public KreirajIgracaFormaController(KreirajIgracaForma kif, Igrac i) {
        this.kif = kif;
        kif.setLocationRelativeTo(null);
        kif.setTitle("Kreiraj igraca");
        kif.getjButtonZapamti().setVisible(false);
        sveKategorije = cordinator.Cordinator.getInstance().getKategorijeIgraca();
        kif.getjComboBoxKategorije().addItem(null);
        for (KategorijaIgraca ki : sveKategorije) {
            kif.getjComboBoxKategorije().addItem(ki);
        }
        kif.getjTextFieldImePrezime().setEnabled(false);
        kif.getjComboBoxKategorije().setEnabled(false);
        kif.getjButtonObrisi().setVisible(false);
        kif.getjButtonOmoguciIzmenu().setVisible(false);
        if (i != null) {
            this.i = i;
            kif.setTitle("Prikaz igraca");
            kif.getjLabelNaslov().setText("Prikaz igraca");
            pregled = true;
            kif.getjButtonKreiraj().setVisible(false);
            kif.getjButtonZapamti().setVisible(false);
            kif.getjButtonOmoguciIzmenu().setVisible(true);
            kif.getjTextFieldImePrezime().setText(i.getImePrezime());
            kif.getjComboBoxKategorije().setSelectedItem(i.getKategorijaIgraca());
            kif.getjButtonObrisi().setVisible(true);

        }
        addActionListeners();
    }

    private void addActionListeners() {
        kif.kreiraj(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String imePrezime = kif.getjTextFieldImePrezime().getText();
                KategorijaIgraca kategorija = (KategorijaIgraca) kif.getjComboBoxKategorije().getSelectedItem();

                /*if(imePrezime.isEmpty()){
                    JOptionPane.showMessageDialog(kif, "Sistem ne moze da kreira igraca.", "Greska", JOptionPane.ERROR_MESSAGE);
                    return;
                }*/
                Igrac i = new Igrac();
                i.setImePrezime(imePrezime);
                i.setKategorijaIgraca(cordinator.Cordinator.getInstance().getNepoznataKaegorija());

                komunikacija.Komunikacija.getInstance().kreirajIgraca(i);
            }
        });
        kif.zapamti(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String imePrezime = kif.getjTextFieldImePrezime().getText();
                KategorijaIgraca kategorija = (KategorijaIgraca) kif.getjComboBoxKategorije().getSelectedItem();
                if (kategorija == null || imePrezime.isEmpty()) {
                    JOptionPane.showMessageDialog(kif, "Sistem ne moze da zapamti igraca.", "Greska", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                i.setImePrezime(imePrezime);
                i.setKategorijaIgraca(kategorija);
                komunikacija.Komunikacija.getInstance().zapamtiIgraca(i);
                JOptionPane.showMessageDialog(kif, "Sistem je zapamtio igraca.", "Uspeh", JOptionPane.INFORMATION_MESSAGE);
                if (pregled) {
                    cordinator.Cordinator.getInstance().osveziTabeluIgracZbogIzmene(i);
                } else {
                    List<Igrac> igraci = cordinator.Cordinator.getInstance().getIgraci();
                    int index = igraci.indexOf(i);
                    if (index != -1) {
                        igraci.set(index, i); // zameni starog
                    } else {
                        igraci.add(i); // ako ne postoji, dodaj novog
                    }
                }
                kif.dispose();

            }
        });

        kif.omoguciIzmenu(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                kif.getjComboBoxKategorije().setEnabled(true);
                kif.setTitle("Izmena igraca");
                kif.getjLabelNaslov().setText("Izmena igraca");
                kif.getjButtonOmoguciIzmenu().setVisible(false);
                kif.getjButtonZapamti().setVisible(true);

            }
        });
        kif.obrisi(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                komunikacija.Komunikacija.getInstance().izbrisiIgraca(i);

            }
        });
    }

    public void otvoriFormu() {
        kif.setVisible(true);
    }

    public void kreiranIgrac(int idIgrac) {
        if (idIgrac == -1) {
            JOptionPane.showMessageDialog(kif, "Sistem ne moze da kreira igraca.", "Greska", JOptionPane.ERROR_MESSAGE);
            return;
        }
        JOptionPane.showMessageDialog(kif, "Sistem je kreirao igraca.", "Uspeh", JOptionPane.INFORMATION_MESSAGE);

        i = new Igrac();
        i.setIdIgrac(idIgrac);
        i.setImePrezime(kif.getjTextFieldImePrezime().getText());
        i.setKategorijaIgraca((KategorijaIgraca) kif.getjComboBoxKategorije().getSelectedItem());

        cordinator.Cordinator.getInstance().getIgraci().add(i);

        cordinator.Cordinator.getInstance().osveziTabeluIgracZbogIzmene(i);

        kif.getjButtonKreiraj().setVisible(false);
        kif.getjButtonZapamti().setVisible(true);
        kif.getjComboBoxKategorije().setEnabled(true);
        kif.getjTextFieldImePrezime().setEnabled(true);
    }

    public void brisanjeUspesno(boolean uspeh) {
        if (uspeh) {
            JOptionPane.showMessageDialog(kif, "Sistem je obrisao igraca.", "Uspeh", JOptionPane.INFORMATION_MESSAGE);
            cordinator.Cordinator.getInstance().osveziTabeluPrikazIgracaZbogBrisanja();
        } else {
            JOptionPane.showMessageDialog(kif, "Sistem ne moze da obrise igraca.", "Greska", JOptionPane.ERROR_MESSAGE);

        }
        kif.dispose();
    }
}
