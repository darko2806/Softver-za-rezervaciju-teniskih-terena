/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package kontroleri;

import forme.PrikazRecepcionaraForma;
import forme.model.ModelRecepcionarSmena;
import java.util.List;
import model.RecepcionarSmena;

/**
 *
 * @author dare2
 */
public class PrikazRecepcionaraFormaController {
    private final PrikazRecepcionaraForma prf;
    private List<RecepcionarSmena> recepcionarSmene = cordinator.Cordinator.getInstance().getRecepcionarSmene();
    private ModelRecepcionarSmena model;
    
    public PrikazRecepcionaraFormaController(PrikazRecepcionaraForma prf) {
        this.prf = prf;
        prf.setLocationRelativeTo(null);
        prf.setTitle("Prikaz recepcionara");
        popuniTabelu(recepcionarSmene);
    }
    
    public void otvoriFormu() {
        prf.setVisible(true);
    }
    
    private void popuniTabelu(List<RecepcionarSmena> RecepcionarSmene) {
        model = new ModelRecepcionarSmena(RecepcionarSmene);
        prf.getjTableRecepcionari().setModel(model);
    }
}
