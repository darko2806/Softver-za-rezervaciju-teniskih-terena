/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package forme.model;

import javax.swing.table.AbstractTableModel;

import java.util.*;
import java.util.stream.Collectors;
import model.TipTerena;

/**
 *
 * @author dare2
 */
public class ModelTipTerena extends AbstractTableModel {
    
    List<TipTerena> lista;
    String[] kolone = {"Opis", "Cena po satu"};

    public ModelTipTerena(List<TipTerena> lista) {
        this.lista = lista;
    }
    
    @Override
    public int getRowCount() {
        return lista.size();
    }

    @Override
    public int getColumnCount() {
        return kolone.length;
    }

    @Override
    public String getColumnName(int column) {
        return kolone[column];
    }
    
    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        TipTerena tt = lista.get(rowIndex);
        switch (columnIndex) {
            case 0: return tt.getOpis();
            case 1: return tt.getCenaPoSatu();
            
            default: return "N/A";
        }
    }

    public List<TipTerena> getLista() {
        return lista;
    }

    
    
}
