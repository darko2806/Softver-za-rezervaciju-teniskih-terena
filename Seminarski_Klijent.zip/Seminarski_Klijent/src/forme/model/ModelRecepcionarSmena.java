/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package forme.model;

import java.text.SimpleDateFormat;
import java.util.List;
import javax.swing.table.AbstractTableModel;
import model.RecepcionarSmena;

/**
 *
 * @author dare2
 */
public class ModelRecepcionarSmena extends AbstractTableModel {

    List<RecepcionarSmena> lista;
    String[] kolone = {"zaposleni", "radna smena", "datum rada"};

    public ModelRecepcionarSmena(List<RecepcionarSmena> lista) {
        this.lista = lista;
    }

    @Override
    public int getRowCount() {
        return lista.size();
    }

    @Override
    public int getColumnCount() {
        return kolone.length;
    }

    @Override
    public String getColumnName(int column) {
        return kolone[column];
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        RecepcionarSmena rs = lista.get(rowIndex);
        SimpleDateFormat formater = new SimpleDateFormat("dd.MM.yyyy");
        String datumRecSme = rs.getDatumRecepcionarSmena() != null ? formater.format(java.sql.Timestamp.valueOf(rs.getDatumRecepcionarSmena())) : "";
        switch (columnIndex) {
            case 0:
                return rs.getRecepcionar().toString();
            case 1:
                return rs.getSmena().getPocetakSmene() + "-"
                        + rs.getSmena().getKrajSmene();
            case 2:
                return datumRecSme;
            default:
                return null;
        }
    }

    public List<RecepcionarSmena> getLista() {
        return lista;
    }

}
