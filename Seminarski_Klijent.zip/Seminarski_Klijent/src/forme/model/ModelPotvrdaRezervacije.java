/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package forme.model;

import java.util.List;
import javax.swing.table.AbstractTableModel;
import model.PotvrdaRezervacije;

/**
 *
 * @author dare2
 */
public class ModelPotvrdaRezervacije extends AbstractTableModel {

    List<PotvrdaRezervacije> lista;
    String[] kolone = {"obradjen", "ukupna cena", "recepcionar", "igrac"};

    public ModelPotvrdaRezervacije(List<PotvrdaRezervacije> lista) {
        this.lista = lista;
    }

    @Override
    public int getRowCount() {
        return lista.size();
    }

    @Override
    public int getColumnCount() {
        return kolone.length;
    }

    @Override
    public String getColumnName(int column) {
        return kolone[column];
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        PotvrdaRezervacije pr = lista.get(rowIndex);
        switch (columnIndex) {
            case 0:
                return pr.isObradjen() ? "Da" : "Ne";
            case 1:
                return pr.getCenaUkupno();
            case 2:
                return (pr.getRecepcionar() != null) ? pr.getRecepcionar().getImePrezime() : "";
            case 3:
                return (pr.getIgrac() != null) ? pr.getIgrac().getImePrezime() : "";
            default:
                return "";
        }
    }

    public List<PotvrdaRezervacije> getLista() {
        return lista;
    }

}
