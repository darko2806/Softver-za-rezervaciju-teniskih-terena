/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package forme.model;


import java.util.List;
import javax.swing.table.AbstractTableModel;
import model.StavkaRezervacije;

/**
 *
 * @author dare2
 */
public class ModelStavkaRezervacije  extends AbstractTableModel{
    List<StavkaRezervacije> lista;
    String[] kolone = {"cenaRez","brojSati","cena po satu","Tip terena"};

    public ModelStavkaRezervacije(List<StavkaRezervacije> lista) {
        this.lista = lista;
    }
    
    @Override
    public int getRowCount() {
        return lista.size();
    }

    @Override
    public int getColumnCount() {
        return kolone.length;
    }

    @Override
    public String getColumnName(int column) {
        return kolone[column];
    }
    
    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        StavkaRezervacije sr = lista.get(rowIndex);
        switch (columnIndex) {
            case 0:
                return sr.getCenaRez();
            case 1:
                return sr.getBrojSati();
            case 2:
                return sr.getCenaPoSatu();
            case 3:
                return sr.getTipTerena();
            default:
                return null;
        }
    }

    public List<StavkaRezervacije> getLista() {
        return lista;
    }
    
}
