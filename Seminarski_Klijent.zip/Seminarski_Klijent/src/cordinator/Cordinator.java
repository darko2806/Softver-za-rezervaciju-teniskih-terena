/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cordinator;

import forme.GlavnaForma;
import forme.KreirajIgracaForma;
import forme.KreirajPotvrduRezervacijeForma;
import forme.LoginForma;
import forme.PrikazIgracaForma;
import forme.PrikazPotvrdaRezervacijeForma;
import forme.PrikazRecepcionaraForma;
import forme.UbaciRecepcionarSmenaForma;
import java.util.ArrayList;
import java.util.List;
import kontroleri.GlavnaFormaController;
import kontroleri.KreirajIgracaFormaController;
import kontroleri.KreirajPotvrduRezervacijeFormaController;
import kontroleri.LoginFormaController;
import kontroleri.PrikazIgracaFormaController;
import kontroleri.PrikazPotvrdaRezervacijeFormaController;
import kontroleri.PrikazRecepcionaraFormaController;
import kontroleri.UbaciRecepcionarSmenaFormaController;
import model.Igrac;
import model.KategorijaIgraca;
import model.PotvrdaRezervacije;
import model.RadnaSmena;
import model.Recepcionar;
import model.RecepcionarSmena;
import model.TipTerena;

/**
 *
 * @author dare2
 */
public class Cordinator {

    private static Cordinator instance;
    private boolean konekcija = false;
    private Recepcionar ulogovani;

    private LoginFormaController lfController;
    private GlavnaFormaController gfController;
    private PrikazIgracaFormaController pifController;
    private KreirajIgracaFormaController kifController;
    private PrikazRecepcionaraFormaController prfController;
    private UbaciRecepcionarSmenaFormaController ursfController;
    private PrikazPotvrdaRezervacijeFormaController pprfController;
    private KreirajPotvrduRezervacijeFormaController kprfController;

    private List<KategorijaIgraca> kategorijeIgraca = new ArrayList<>();
    private List<Igrac> igraci = new ArrayList<>();
    private List<Recepcionar> recepcionari = new ArrayList<>();
    private List<TipTerena> tipoviTerena = new ArrayList<>();
    private List<RecepcionarSmena> recepcionarSmene = new ArrayList<>();
    private List<RadnaSmena> radneSmene = new ArrayList<>();
    private List<PotvrdaRezervacije> potvrdeRezervacije = new ArrayList<>();
    private KategorijaIgraca nepoznataKategorija;
    private Recepcionar nepoznatiRecepcionar;
    private Igrac nepoznatIgrac;

    private Cordinator() {
    }

    public static Cordinator getInstance() {
        if (instance == null) {
            instance = new cordinator.Cordinator();
        }
        return instance;
    }

    public void otvoriLoginFormu() {
        lfController = new LoginFormaController(new LoginForma());
        lfController.otvoriFormu();
    }

    public void login(Recepcionar recepcionar) {
        lfController.login(recepcionar);
    }

    public Recepcionar getUlogovani() {
        return ulogovani;
    }

    public void setUlogovani(Recepcionar ulogovani) {
        this.ulogovani = ulogovani;
    }

    public void otvoriGlavnuFormu() {
        gfController = new GlavnaFormaController(new GlavnaForma());
        gfController.otvoriFormu();
    }

    public void uspostavljenaKonekcija() {
        konekcija = true;
    }

    public boolean isKonekcija() {
        return konekcija;
    }

    public void setKonekcija(boolean konekcija) {
        this.konekcija = konekcija;
    }

    public void ugasiFormu() {
        lfController.ugasiFormu();
    }

    public List<KategorijaIgraca> getKategorijeIgraca() {
        return kategorijeIgraca;
    }

    public void setKategorijeIgraca(List<KategorijaIgraca> kategorije) {

        for (KategorijaIgraca kategorija : kategorije) {
            if (kategorija.getNazivKategorije().equals("Nepoznato")) {
                nepoznataKategorija = kategorija;

                break;
            }
        }
        kategorije.remove(nepoznataKategorija);
        this.kategorijeIgraca = kategorije;
    }

    public List<Igrac> getIgraci() {
        return igraci;
    }

    public void setIgraci(List<Igrac> igraci) {
        for (Igrac igrac : igraci) {
            if (igrac.getImePrezime().equals("Nepoznato")) {
                nepoznatIgrac = igrac;

                break;
            }
        }
        igraci.remove(nepoznatIgrac);
        this.igraci = igraci;
    }

    public void otvoriPrikazIgracaFormu() {
        if (kategorijeIgraca == null || kategorijeIgraca.isEmpty()) {
            komunikacija.Komunikacija.getInstance().vratiKategorijeIgraca();
        }
        if (igraci == null || igraci.isEmpty()) {
            komunikacija.Komunikacija.getInstance().vratiIgrace();
        }

        pifController = new PrikazIgracaFormaController(new PrikazIgracaForma());
        pifController.otvoriFormu();
    }

    public void osveziTabeluPrikazIgracaZbogBrisanja() {
        if (pifController != null) {
            pifController.osveziTabeluPrikazIgracaZbogBrisanja();
        }

    }

    public void otvoriKreirajIgracaFormu() {
        kifController = new KreirajIgracaFormaController(new KreirajIgracaForma(), null);
        kifController.otvoriFormu();
    }

    public void kreiranIgrac(int idIgrac) {
        kifController.kreiranIgrac(idIgrac);
    }

    public void uspehBrisanje(boolean uspehBrisanje) {
        kifController.brisanjeUspesno(uspehBrisanje);
    }

    public KategorijaIgraca getNepoznataKaegorija() {
        return nepoznataKategorija;
    }

    public void osveziTabeluIgracZbogIzmene(Igrac i) {
        if (pifController != null) {
            pifController.osveziTabeluPrikazIgracaZbogIzmene(i);
        }
    }

    public void otvoriPregledIgraca(Igrac i) {
        kifController = new KreirajIgracaFormaController(new KreirajIgracaForma(), i);
        kifController.otvoriFormu();
    }

    public void pretrazeniIgraci(List<Igrac> pretrazeniIgraci) {
        if (pifController != null) {
            pifController.pretrazeniIgraci(pretrazeniIgraci);
        }
    }

    public void setRecepcionari(List<Recepcionar> recepcionari) {
        for (Recepcionar recepcionar : recepcionari) {
            if (recepcionar.getImePrezime().equals("Nepoznato")) {
                nepoznatiRecepcionar = recepcionar;

                break;
            }
        }
        recepcionari.remove(nepoznatiRecepcionar);
        this.recepcionari = recepcionari;
    }

    public List<Recepcionar> getRecepcionari() {
        return recepcionari;
    }

    public List<TipTerena> getTipoviTerena() {
        return tipoviTerena;
    }

    public void setTipoviTerena(List<TipTerena> tipoviTerena) {
        this.tipoviTerena = tipoviTerena;
    }

    public Recepcionar getNepoznatiRecepcionar() {
        return nepoznatiRecepcionar;
    }

    public Igrac getNepoznatiIgrac() {
        return nepoznatIgrac;
    }

    public void setRecepcionarSmene(List<RecepcionarSmena> recepcionarSmene) {
        this.recepcionarSmene = recepcionarSmene;
    }

    public List<RecepcionarSmena> getRecepcionarSmene() {
        return recepcionarSmene;
    }

    public List<RadnaSmena> getRadneSmene() {
        return radneSmene;
    }

    public void setRadneSmene(List<RadnaSmena> radneSmene) {
        this.radneSmene = radneSmene;
    }

    public void otvoriPrikazRecepcionari() {
        prfController = new PrikazRecepcionaraFormaController(new PrikazRecepcionaraForma());
        prfController.otvoriFormu();
    }

    public void otvoriUbaciFormu() {
        ursfController = new UbaciRecepcionarSmenaFormaController(new UbaciRecepcionarSmenaForma());
        ursfController.otvoriFormu();
    }

    public void otvoriPrikazPotvrdaRezervacijeFormu() {
        pprfController = new PrikazPotvrdaRezervacijeFormaController(new PrikazPotvrdaRezervacijeForma());
        pprfController.otvoriFormu();
    }

    public void otvoriKreirajPotvrduRezervacijeFormu() {
        kprfController = new KreirajPotvrduRezervacijeFormaController(new KreirajPotvrduRezervacijeForma(), null);
        kprfController.otvoriFormu();
    }

    public void svePotvrde(List<PotvrdaRezervacije> svePotvrde) {
        potvrdeRezervacije = svePotvrde;
    }

    public List<PotvrdaRezervacije> getPotvrde() {
        return potvrdeRezervacije;
    }

    public void otvoriPromeniPotvrduRezervacije(PotvrdaRezervacije pr) {
        kprfController = new KreirajPotvrduRezervacijeFormaController(new KreirajPotvrduRezervacijeForma(), pr);
        kprfController.otvoriFormu();
    }

    public void pretragaPodvrda(List<PotvrdaRezervacije> pretragaPotvrda) {
        pprfController.pretragaPotvrdaRez(pretragaPotvrda);
    }

    public void kreirajPotvrdu(int id) {
        kprfController.kreiranaPotvrda(id);
    }

    public void osveziPrikazPotvrdi(PotvrdaRezervacije pr) {
        pprfController.osveziTabelu(pr);
    }

    public void zapamcenaPotvrda(PotvrdaRezervacije zapamcenaPotvrda) {
        if (potvrdeRezervacije.contains(zapamcenaPotvrda)) {
            int id = potvrdeRezervacije.indexOf(zapamcenaPotvrda);
            potvrdeRezervacije.set(id, zapamcenaPotvrda);
        } else {
            potvrdeRezervacije.add(zapamcenaPotvrda);
        }
    }

}
