/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main;

import cordinator.Cordinator;

/**
 *
 * @author dare2
 */
public class Main {
    public static void main(String[] args) {
        Cordinator.getInstance().otvoriLoginFormu();
    }
}
