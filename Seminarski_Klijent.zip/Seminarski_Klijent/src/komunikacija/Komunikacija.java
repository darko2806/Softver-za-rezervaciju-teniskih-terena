/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package komunikacija;

import java.io.IOException;
import java.net.Socket;
import java.util.List;
import java.util.Map;
import model.Igrac;
import model.KategorijaIgraca;
import model.PotvrdaRezervacije;
import model.RadnaSmena;
import model.Recepcionar;
import model.RecepcionarSmena;
import model.TipTerena;

/**
 *
 * @author dare2
 */
public class Komunikacija extends Thread {

    Socket soket;
    private static Komunikacija instance;
    Posiljalac posiljalac;
    Primalac primalac;

    private Komunikacija() {

    }

    public void konekcija() throws IOException {
        soket = new Socket("localhost", 9000);
        posiljalac = new Posiljalac(soket);
        primalac = new Primalac(soket);
        instance.start();

    }

    public static Komunikacija getInstance() {
        if (instance == null) {
            instance = new Komunikacija();

        }
        return instance;
    }

    @Override
    public void run() {
        try {
            while (true) {
                Odgovor so = (Odgovor) primalac.primi();
                if (so == null) {
                    break;
                }
                switch (so.getOperacija()) {
                    case LOGIN:
                        Recepcionar recepcionar = (Recepcionar) so.getOdgovor();
                        cordinator.Cordinator.getInstance().login(recepcionar);
                        break;
                    case GASENJE_SERVERA:
                        cordinator.Cordinator.getInstance().ugasiFormu();
                        break;
                    case VRATI_KATEGORIJE_IGRACA:
                        List<KategorijaIgraca> sveKategorije = (List<KategorijaIgraca>) so.getOdgovor();
                        cordinator.Cordinator.getInstance().setKategorijeIgraca(sveKategorije);
                        break;
                    case VRATI_IGRACE:
                        List<Igrac> sviIgraci = (List<Igrac>) so.getOdgovor();
                        cordinator.Cordinator.getInstance().setIgraci(sviIgraci);
                        break;
                    case KREIRAJ_IGRACA:
                        int idIgrac = (int) so.getOdgovor();
                        cordinator.Cordinator.getInstance().kreiranIgrac(idIgrac);
                        break;
                    case OBRISI_IGRACA:
                        boolean uspehBrisanje = (boolean) so.getOdgovor();
                        cordinator.Cordinator.getInstance().uspehBrisanje(uspehBrisanje);
                        break;
                    case PRETRAZI_IGRACA:
                        List<Igrac> pretrazeniIgraci = (List<Igrac>) so.getOdgovor();
                        cordinator.Cordinator.getInstance().pretrazeniIgraci(pretrazeniIgraci);
                        break;
                    case VRATI_RECEPCIONARE:
                        List<Recepcionar> sviRecepcionari = (List<Recepcionar>) so.getOdgovor();
                        cordinator.Cordinator.getInstance().setRecepcionari(sviRecepcionari);
                        break;
                    case VRATI_TIPOVE_TERENA:
                        List<TipTerena> tipoviTerena = (List<TipTerena>) so.getOdgovor();
                        cordinator.Cordinator.getInstance().setTipoviTerena(tipoviTerena);
                        break;
                    case VRATI_RECEPCIONARSMENA:
                        List<RecepcionarSmena> recSme = (List<RecepcionarSmena>) so.getOdgovor();
                        cordinator.Cordinator.getInstance().setRecepcionarSmene(recSme);
                        break;
                    case VRATI_RADNASMENA:
                        List<RadnaSmena> radneSmene = (List<RadnaSmena>) so.getOdgovor();
                        cordinator.Cordinator.getInstance().setRadneSmene(radneSmene);
                        break;
                    case VRATI_POTVRDE_REZERVACIJE:
                        List<PotvrdaRezervacije> svePotvrde = (List<PotvrdaRezervacije>) so.getOdgovor();
                        cordinator.Cordinator.getInstance().svePotvrde(svePotvrde);
                        break;
                    case PRETRAZI_POTVRDE_REZERVACIJE:
                        List<PotvrdaRezervacije> pretragaPotvrdi = (List<PotvrdaRezervacije>) so.getOdgovor();
                        cordinator.Cordinator.getInstance().pretragaPodvrda(pretragaPotvrdi);
                        break;
                    case KREIRAJ_POTVRDU_REZERVACIJE:
                        int id = (int) so.getOdgovor();
                        cordinator.Cordinator.getInstance().kreirajPotvrdu(id);
                        break;
                    case ZAPAMTI_POTVRDU_REZERVACIJE:
                        PotvrdaRezervacije zapamcenaPotvrda = (PotvrdaRezervacije) so.getOdgovor();
                        cordinator.Cordinator.getInstance().zapamcenaPotvrda(zapamcenaPotvrda);
                        break;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("ERROR");
        }
    }

    public void login(Recepcionar recepcionar) {
        Zahtev z = new Zahtev(Operacija.LOGIN, recepcionar);
        posiljalac.posalji(z);
    }

    public void logout(Recepcionar ulogovani) {
        Zahtev z = new Zahtev(Operacija.LOGOUT, ulogovani);
        posiljalac.posalji(z);
    }

    public void vratiKategorijeIgraca() {
        Zahtev z = new Zahtev(Operacija.VRATI_KATEGORIJE_IGRACA, null);
        posiljalac.posalji(z);
    }

    public void vratiIgrace() {
        Zahtev z = new Zahtev(Operacija.VRATI_IGRACE, null);
        posiljalac.posalji(z);
    }

    public void kreirajIgraca(Object o) {
        Zahtev z = new Zahtev(Operacija.KREIRAJ_IGRACA, o);
        posiljalac.posalji(z);
    }

    public void izbrisiIgraca(Igrac i) {
        Zahtev z = new Zahtev(Operacija.OBRISI_IGRACA, i);
        posiljalac.posalji(z);
    }

    public void zapamtiIgraca(Igrac i) {
        Zahtev z = new Zahtev(Operacija.ZAPAMTI_IGRACA, i);
        posiljalac.posalji(z);
    }

    public void pretraziIgrace(Map<String, Object> mapa) {
        Zahtev z = new Zahtev(Operacija.PRETRAZI_IGRACA, mapa);
        posiljalac.posalji(z);
    }

    public void vratiRecepcionare() {
        Zahtev z = new Zahtev(Operacija.VRATI_RECEPCIONARE, null);
        posiljalac.posalji(z);
    }

    public void vratiTipoveTerena() {
        Zahtev z = new Zahtev(Operacija.VRATI_TIPOVE_TERENA, null);
        posiljalac.posalji(z);
    }

    public void vratiRecepcionarSmena() {
        Zahtev z = new Zahtev(Operacija.VRATI_RECEPCIONARSMENA, null);
        posiljalac.posalji(z);
    }

    public void vratiRadnaSmena() {
        Zahtev z = new Zahtev(Operacija.VRATI_RADNASMENA, null);
        posiljalac.posalji(z);
    }

    public void ubaciRecepcionarSmenu(RecepcionarSmena rs) {
        Zahtev z = new Zahtev(Operacija.UBACI_RECEPCIONARSMENU, rs);
        posiljalac.posalji(z);
    }

    public void vratiPotvrdeRezervaciije() {
        Zahtev z = new Zahtev(Operacija.VRATI_POTVRDE_REZERVACIJE, null);
        posiljalac.posalji(z);
    }

    public void pretraziPotvrde(Map<String, Object> mapa) {
        Zahtev z = new Zahtev(Operacija.PRETRAZI_POTVRDE_REZERVACIJE, mapa);
        posiljalac.posalji(z);
    }

    public void kreirajPotvrduRezervacije(PotvrdaRezervacije kreiranaPotvrda) {
        Zahtev z = new Zahtev(Operacija.KREIRAJ_POTVRDU_REZERVACIJE, kreiranaPotvrda);
        posiljalac.posalji(z);
    }

    public void izbrisiPotvrdu(PotvrdaRezervacije kreiranaPotvrda) {
        Zahtev z = new Zahtev(Operacija.OBRISI_POTVRDU_REZERVACIJE, kreiranaPotvrda);
        posiljalac.posalji(z);
    }

    public void zapamtiPotvrdu(Map<String, Object> mapa) {
        Zahtev z = new Zahtev(Operacija.ZAPAMTI_POTVRDU_REZERVACIJE, mapa);
        posiljalac.posalji(z);
    }
}
